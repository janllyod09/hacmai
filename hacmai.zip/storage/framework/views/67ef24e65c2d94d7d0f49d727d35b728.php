<section>
    <div class="px-4 py-12 mx-auto md:px-16 lg:px-32 max-w-5xl">
        <div class="max-w-4xl mx-auto md:max-w-5xl md:w-full">
            <div class="flex flex-col text-center">
                <h1 class="text-4xl font-semibold tracking-tight text-gray-900">
                    HACMAI ELECTION Form
                </h1>
            </div>
            <div class="p-4 mt-8 border bg-gray-50 rounded-3xl">
                <div class="p-8 md:p-12 bg-white border shadow-lg rounded-2xl">
                    <div>
                        <h2 class="text-lg font-medium text-gray-500">
                            <span class="font-bold text-black">Please fill up all the fields.</span>
                        </h2>

                        <!-- Name Fields -->
                        <div class="mt-12 gap-6 lg:columns-3 sm:columns-1">
                            <div class="w-full">
                                <label for="firstname" class="text-sm text-gray-700">First Name <span
                                        class="text-red-600">*</span></label>
                                <input type="text" id="first_name" wire:model.live="first_name"
                                    placeholder="Enter First Name"
                                    class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="w-full">
                                <label for="middlename" class="text-sm text-gray-700">Middle Name</label>
                                <input type="text" id="middle_name" wire:model.live="middle_name"
                                    placeholder="Enter Middle Name"
                                    class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm">
                            </div>
                            <div class="w-full">
                                <label for="last_name" class="text-sm text-gray-700">Last Name <span
                                        class="text-red-600">*</span></label>
                                <input type="text" id="last_name" wire:model.live="last_name"
                                    placeholder="Enter Last Name"
                                    class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <!-- Address Field -->
                        <div class="mt-4 gap-6 lg:columns-2 sm:columns-1">
                            <div class="gap-6 lg:columns-2">
                                <div class="w-full">
                                    <label for="blk" class="text-sm text-gray-700">Blk <span
                                            class="text-red-600">*</span></label>
                                    <input type="text" id="blk" wire:model.live="blk"
                                        class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="Enter Blk">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['blk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="w-full">
                                    <label for="lot" class="text-sm text-gray-700">Lot <span
                                            class="text-red-600">*</span></label>
                                    <input type="text" id="lot" wire:model.live="lot"
                                        class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                        placeholder="Enter Lot">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <div class="w-full">
                                <label for="street" class="text-sm text-gray-700">Street <span
                                        class="text-red-600">*</span></label>
                                <input type="text" id="street" wire:model.live="street"
                                    class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                                    placeholder="Enter street">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>


                        <!-- Position Field -->
                        <div class="mt-4">
                            <label for="position" class="text-sm text-gray-700">Position <span
                                    class="text-red-600">*</span></label>
                            <select id="position" wire:model.live="position"
                                class="w-full h-12 px-4 py-2 text-black border rounded-lg appearance-none bg-white border-zinc-300 placeholder-zinc-300 focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm">
                                <option value="">Select Position</option>
                                <option value="President">President</option>
                                <option value="Vice President">Vice President</option>
                                <option value="Secretary">Secretary</option>
                                <option value="Treasurer">Treasurer</option>
                                <option value="Auditor">Auditor</option>
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <!-- Qualifications -->
                        <div class="flex flex-col gap-4 mt-2">
                            <div>
                                <input type="checkbox" id="qualification1" value="Must be of legal age"
                                    wire:model="qualifications" class="mr-2">
                                <label for="qualification1" class="text-sm text-gray-700">Must be of legal age</label>
                            </div>
                            <div>
                                <input type="checkbox" id="qualification2" value="Must be in good standing"
                                    wire:model="qualifications" class="mr-2">
                                <label for="qualification2" class="text-sm text-gray-700">Must be in good
                                    standing</label>
                            </div>
                            <div>
                                <input type="checkbox" id="qualification3"
                                    value="Must be an actual resident of Courtyard of Maia Alta for at least six (6) months as certified by the association secretary"
                                    wire:model="qualifications" class="mr-2">
                                <label for="qualification3" class="text-sm text-gray-700">Must be an actual resident
                                    of Courtyard of Maia Alta for at least six (6) months as certified by the
                                    association secretary</label>
                            </div>
                            <div>
                                <input type="checkbox" id="qualification4"
                                    value="Has not been convicted by final judgement of an offense involving moral turpitude"
                                    wire:model="qualifications" class="mr-2">
                                <label for="qualification4" class="text-sm text-gray-700">Has not been convicted by
                                    final judgement of an offense involving moral turpitude</label>
                            </div>
                            <div>
                                <input type="checkbox" id="qualification5"
                                    value="Legitimate Spouse of a member may be a candidate in lieu of the member - in accordance with the provisions of Rule 9 of Implementing Rules and Regulations of Magna Carta for Homeowners and Homeowners Associations"
                                    wire:model="qualifications" class="mr-2">
                                <label for="qualification5" class="text-sm text-gray-700">Legitimate Spouse of a
                                    member may be a candidate in lieu of the member - in accordance with the provisions
                                    of Rule 9 of Implementing Rules and Regulations of Magna Carta for Homeowners and
                                    Homeowners Associations</label>
                            </div>
                        </div>


                        <!-- Submit and Print Button -->
                        <div class="mt-8 text-center">
                            <button type="button" wire:click="generatePdf"
                                class="px-6 py-2 text-white bg-gray-600 rounded-lg hover:bg-gray-700 focus:outline-none">
                                Print to PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\janllyod09\Desktop\project\projecthacmai\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>